-- ============================================
-- ESTRUCTURA DE TABLAS PARA API DE CITAS
-- Base de Datos: PostgreSQL
-- Autor: Romeo Cuahua Galvez
-- ============================================

-- ============================================
-- CREACI�N DE TABLA PERSONAS
-- ============================================
CREATE TABLE personas (
  id_persona     SERIAL PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  email          VARCHAR(100),
  telefono       VARCHAR(20)
);

-- ============================================
-- CREACI�N DE TABLA CITAS (ACTUALIZADA)
-- ============================================
CREATE TABLE citas (
  id_cita         SERIAL PRIMARY KEY,
  id_persona      INTEGER NOT NULL,
  titulo          VARCHAR(100) NOT NULL,
  fecha           DATE NOT NULL,
  hora_inicio     TIME NOT NULL,
  hora_final      TIME NOT NULL,
  nombre_cliente  VARCHAR(100),
  numero_cliente  VARCHAR(20),
  motivo          VARCHAR(200),
  CONSTRAINT fk_citas_persona FOREIGN KEY (id_persona)
    REFERENCES personas(id_persona)
);

-- ============================================
-- CREACI�N DE TABLA AVISOS
-- ============================================
CREATE TABLE avisos (
  id_aviso       SERIAL PRIMARY KEY,
  id_persona     INTEGER NOT NULL,
  id_cita        INTEGER NOT NULL,
  mensaje        VARCHAR(300) NOT NULL,
  fecha_aviso    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_avisos_persona FOREIGN KEY (id_persona)
    REFERENCES personas(id_persona),
  CONSTRAINT fk_avisos_cita FOREIGN KEY (id_cita)
    REFERENCES citas(id_cita)
);

-- ============================================
-- CREACI�N DE TABLA USUARIOS (para login)
-- ============================================
CREATE TABLE usuarios (
  id_usuario     SERIAL PRIMARY KEY,
  nombre         VARCHAR(100) NOT NULL,
  correo         VARCHAR(100) UNIQUE NOT NULL,
  telefono       VARCHAR(20),
  password       VARCHAR(255) NOT NULL -- Aqu� se guarda el hash
);
